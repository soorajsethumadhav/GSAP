# reveal-animation-gsap-scrolltrigger

<p>Test an animation with gsap ScrollTrigger<p>

