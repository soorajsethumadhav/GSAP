# OGTech - digital agency website (unofficial)
#### This is a responsive website for a digital agency based on https://www.wolfwhale.com/ and https://www.weareimpero.com/

### :rocket: [DEMO](https://ogtech.netlify.com/)

# What I learned

 * [x] SASS, JS, JQuery, Parcel, Babel
 * [x] Responsive design
 * [x] GSAP
 * [x] ScrollMagic
 * [x] UI/UX
 * [ ] Update dependencies(forge, parser, sass)

