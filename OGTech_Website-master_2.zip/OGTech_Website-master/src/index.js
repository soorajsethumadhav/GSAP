

import MainAnimations from './scripts/Global/Animations/MainAnimations';
 
import MobileNav from './scripts/mobileNav/mobileNav';


 
 
 console.log(window.pageYOffset);